import java.lang.*;

public class Main
{
	public static void main(String args[])
	{
		FirstFrame f = new FirstFrame();
		f.setVisible(true);
	}
}